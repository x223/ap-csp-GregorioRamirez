function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background('white');

	fill('black') 
rect(150,100,100,200) 	
	fill('white')
ellipse(200,140,45,45) 
ellipse(200,200,45,45)
ellipse(200,260,45,45)
	fill('grey')
	rect(190,300,20,100)
}
